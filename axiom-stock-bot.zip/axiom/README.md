# AXIOM — AI Portfolio Intelligence

Your personal AI stock market analyst. Covers USD and CAD markets, regular stocks and penny stocks.

## Deploy to Vercel (5 minutes)

### Step 1 — Upload to GitHub
1. Go to [github.com](https://github.com) and sign in (or create a free account)
2. Click the **+** button → **New repository**
3. Name it `axiom-stock-bot`, set to **Public**, click **Create repository**
4. Upload all these files (drag and drop the entire folder)

### Step 2 — Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click **Add New Project**
3. Select your `axiom-stock-bot` repository
4. Leave all settings as default → click **Deploy**
5. Wait ~2 minutes → you get a live URL like `axiom-stock-bot.vercel.app`

### Step 3 — Add to Desktop
**Chrome/Edge:**
1. Open your Vercel link
2. Click the `...` menu → **More tools** → **Create shortcut**
3. Check "Open as window" → **Create**
4. AXIOM appears on your desktop as a standalone app!

## Usage
On first launch, click ⚙️ and paste your Anthropic API key.
Get a free key at: https://console.anthropic.com/keys

## Features
- Daily & weekly stock analysis with live web search
- USD and CAD stock recommendations
- Penny stock analysis with risk warnings
- Portfolio tracker with buy/sell/hold signals
- Entry price, stop-loss, target price, confidence score on every pick
