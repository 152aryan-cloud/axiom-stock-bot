import { useState, useEffect, useRef } from "react";
import "./App.css";

const STORAGE_KEY = "axiom_portfolio_v2";

const SYSTEM_PROMPT = `You are AXIOM — an elite AI stock market analyst and portfolio manager with expertise in:
- Regular stocks (NYSE, NASDAQ, TSX) in both USD and CAD
- Penny stocks (under $5 USD / $5 CAD) — high risk/reward
- Technical analysis: chart patterns, support/resistance, moving averages, RSI, MACD
- Fundamental analysis: P/E ratios, earnings, revenue growth, debt levels
- News sentiment analysis and macro-economic factors
- Sector rotation and market cycles
- Both Canadian (TSX) and US market dynamics

YOUR CORE RESPONSIBILITIES:
1. Daily Analysis: Review news, analyze owned stocks, give hold/sell/watch insights
2. Weekly Sunday Report: Comprehensive buy/sell recommendations with full reasoning
3. Portfolio Memory: Always reference the user's current holdings
4. Stock Profiling: Build behavioral profiles (how stocks react to news, earnings, macro events)
5. Precise Recommendations — always include:
   - Recommended quantity to buy
   - Entry price range (e.g. "Buy between $X.XX–$X.XX")
   - Stop-loss price (critical!)
   - Target sell price range
   - Expected profit % and estimated timeline
   - Confidence score (0–100%)
   - Risk level (Low / Medium / High / Very High)
   - Currency (USD or CAD)

PENNY STOCK RULES:
- Never recommend more than 15% of portfolio in a single penny stock
- Always flag liquidity risk (low volume = hard to exit)
- Flag pump-and-dump warning signs
- Recommend smaller position sizes

FORMAT YOUR RESPONSES:
- Use **bold** for section headers
- Be direct, specific, confident
- End daily updates with a market mood: Bearish 🔴 / Neutral 🟡 / Bullish 🟢
- Reference past behavior patterns when known
- Always note the currency (USD/CAD) for each recommendation`;

const defaultPortfolio = {
  holdings: [],
  watchlist: [],
  riskProfile: "Moderate",
  totalInvested: 0,
};

const QUICK_PROMPTS = [
  { label: "📊 Sunday Report", msg: "Give me the full Sunday weekly buy/sell report with your top picks and full analysis." },
  { label: "🌅 Morning Update", msg: "Good morning! Give me today's daily market update and review my current holdings." },
  { label: "📉 Review Holdings", msg: "Review all my current holdings. Should I hold, sell, or add to any positions?" },
  { label: "💎 Top Penny Stocks", msg: "What are the best penny stocks to watch this week? Top 3 picks with full details." },
  { label: "🇨🇦 CAD Picks", msg: "What are your top Canadian TSX stock picks this week?" },
  { label: "⚡ Momentum Plays", msg: "What stocks have the strongest momentum right now for short-term plays?" },
];

export default function App() {
  const [portfolio, setPortfolio] = useState(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEY);
      return s ? JSON.parse(s) : defaultPortfolio;
    } catch { return defaultPortfolio; }
  });
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: `**AXIOM online** — AI Portfolio Intelligence System\n\nI'm your dedicated stock analyst for USD and CAD markets. Here's what I do:\n\n- 🗓️ **Sunday Reports** — Weekly buy/sell recommendations with entry/exit prices\n- 📊 **Daily Updates** — Morning briefings and news sentiment on your holdings\n- 🔍 **Stock Deep Dives** — Full behavioral profiles and analysis\n- 📈 **Portfolio Tracking** — Personalized advice based on your actual positions\n\nSet your **risk profile** in the Portfolio tab, add your holdings, then ask me anything — or use a quick prompt below.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const [showAddForm, setShowAddForm] = useState(false);
  const [newHolding, setNewHolding] = useState({ ticker: "", shares: "", avgPrice: "", currency: "USD", type: "regular", notes: "" });
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("axiom_apikey") || "");
  const [showKeyInput, setShowKeyInput] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(portfolio));
  }, [portfolio]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const saveApiKey = (key) => {
    setApiKey(key);
    localStorage.setItem("axiom_apikey", key);
  };

  const buildContext = () => {
    if (!portfolio.holdings.length) return "Portfolio: EMPTY — no holdings yet.";
    const lines = portfolio.holdings.map(h =>
      `${h.ticker} (${h.type}, ${h.currency}): ${h.shares} shares @ avg $${h.avgPrice}${h.notes ? ` — ${h.notes}` : ""}`
    );
    return `PORTFOLIO (${portfolio.riskProfile} risk profile):\n${lines.join("\n")}\nWatchlist: ${portfolio.watchlist.join(", ") || "empty"}\nTotal invested: $${portfolio.totalInvested.toFixed(0)}`;
  };

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    if (!apiKey) { setShowKeyInput(true); return; }

    const userText = input.trim();
    setInput("");
    setLoading(true);

    const newMessages = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);

    const context = buildContext();
    const apiMessages = newMessages.map((m, i) => ({
      role: m.role,
      content: i === newMessages.length - 1 && m.role === "user"
        ? `[PORTFOLIO CONTEXT]\n${context}\n\n[USER MESSAGE]\n${m.content}`
        : m.content,
    }));

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-calls": "true" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1500,
          system: SYSTEM_PROMPT,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          messages: apiMessages,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const reply = data.content.map(b => b.type === "text" ? b.text : "").filter(Boolean).join("\n");
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: "assistant", content: `⚠️ Error: ${err.message}. Check your API key in settings.` }]);
    }
    setLoading(false);
    inputRef.current?.focus();
  };

  const addHolding = () => {
    if (!newHolding.ticker || !newHolding.shares || !newHolding.avgPrice) return;
    const h = {
      ...newHolding,
      ticker: newHolding.ticker.toUpperCase(),
      shares: parseFloat(newHolding.shares),
      avgPrice: parseFloat(newHolding.avgPrice),
      dateAdded: new Date().toISOString().split("T")[0],
    };
    setPortfolio(prev => ({
      ...prev,
      holdings: [...prev.holdings, h],
      totalInvested: prev.totalInvested + h.shares * h.avgPrice,
    }));
    setNewHolding({ ticker: "", shares: "", avgPrice: "", currency: "USD", type: "regular", notes: "" });
    setShowAddForm(false);
  };

  const removeHolding = (ticker) => {
    setPortfolio(prev => {
      const h = prev.holdings.find(x => x.ticker === ticker);
      return {
        ...prev,
        holdings: prev.holdings.filter(x => x.ticker !== ticker),
        totalInvested: Math.max(0, prev.totalInvested - (h ? h.shares * h.avgPrice : 0)),
      };
    });
  };

  const formatMsg = (text) => {
    return text.split("\n").map((line, i) => {
      let html = line
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/\*(.*?)\*/g, "<em>$1</em>")
        .replace(/`(.*?)`/g, "<code>$1</code>");
      if (line.startsWith("- ") || line.startsWith("• "))
        return <li key={i} dangerouslySetInnerHTML={{ __html: html.slice(2) }} />;
      if (line === "") return <br key={i} />;
      return <p key={i} dangerouslySetInnerHTML={{ __html: html }} />;
    });
  };

  return (
    <div className="app">
      {/* Header */}
      <div className="header">
        <div className="logo">
          <div className="logo-icon">📈</div>
          <div>
            <div className="logo-name">AXIOM</div>
            <div className="logo-sub">AI PORTFOLIO INTELLIGENCE</div>
          </div>
        </div>
        <div className="header-right">
          <div className="status-pill"><div className="dot" /> LIVE</div>
          <button className="key-btn" onClick={() => setShowKeyInput(!showKeyInput)} title="API Key Settings">⚙️</button>
        </div>
      </div>

      {/* API Key Panel */}
      {showKeyInput && (
        <div className="key-panel">
          <span className="key-label">Anthropic API Key:</span>
          <input
            className="key-input"
            type="password"
            placeholder="sk-ant-..."
            value={apiKey}
            onChange={e => saveApiKey(e.target.value)}
          />
          <button className="key-save" onClick={() => setShowKeyInput(false)}>Save</button>
          <a className="key-link" href="https://console.anthropic.com/keys" target="_blank" rel="noreferrer">Get key ↗</a>
        </div>
      )}

      {/* Tabs */}
      <div className="tabs">
        <button className={`tab ${activeTab === "chat" ? "active" : ""}`} onClick={() => setActiveTab("chat")}>
          💬 Analyst Chat
        </button>
        <button className={`tab ${activeTab === "portfolio" ? "active" : ""}`} onClick={() => setActiveTab("portfolio")}>
          📂 Portfolio ({portfolio.holdings.length})
        </button>
      </div>

      {activeTab === "chat" && (
        <>
          <div className="quick-row">
            {QUICK_PROMPTS.map((q, i) => (
              <button key={i} className="qbtn" onClick={() => { setInput(q.msg); inputRef.current?.focus(); }}>{q.label}</button>
            ))}
          </div>
          <div className="chat-area">
            {messages.map((m, i) => (
              <div key={i} className={`msg ${m.role}`}>
                <div className="avatar">{m.role === "assistant" ? "🤖" : "👤"}</div>
                <div className="bubble">{formatMsg(m.content)}</div>
              </div>
            ))}
            {loading && (
              <div className="msg assistant">
                <div className="avatar">🤖</div>
                <div className="bubble"><div className="dots"><span /><span /><span /></div></div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="input-row">
            <textarea
              ref={inputRef}
              className="msg-input"
              placeholder="Ask AXIOM anything… 'What should I buy this week?'"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
              rows={1}
            />
            <button className="send-btn" onClick={sendMessage} disabled={loading || !input.trim()}>➤</button>
          </div>
        </>
      )}

      {activeTab === "portfolio" && (
        <div className="port-area">
          <div className="stats-row">
            <div className="stat"><div className="stat-val">{portfolio.holdings.length}</div><div className="stat-lbl">Holdings</div></div>
            <div className="stat"><div className="stat-val">${portfolio.totalInvested.toFixed(0)}</div><div className="stat-lbl">Invested</div></div>
            <div className="stat"><div className="stat-val">{portfolio.holdings.filter(h => h.type === "penny").length}</div><div className="stat-lbl">Penny Stocks</div></div>
          </div>

          <div className="section-block">
            <div className="section-lbl">Risk Profile</div>
            <div className="risk-row">
              {["Conservative", "Moderate", "Aggressive"].map(r => (
                <button key={r}
                  className={`risk-opt ${portfolio.riskProfile === r ? "active-" + r.toLowerCase() : ""}`}
                  onClick={() => setPortfolio(p => ({ ...p, riskProfile: r }))}>
                  {r === "Conservative" ? "🛡️" : r === "Moderate" ? "⚡" : "🔥"} {r}
                </button>
              ))}
            </div>
          </div>

          <div className="section-block">
            <div className="section-hdr">
              <div className="section-lbl">My Holdings</div>
              <button className="add-btn" onClick={() => setShowAddForm(!showAddForm)}>+ Add Stock</button>
            </div>

            {showAddForm && (
              <div className="add-form">
                <div className="form-grid">
                  {[
                    { label: "Ticker", id: "ticker", placeholder: "AAPL", transform: v => v.toUpperCase() },
                    { label: "Shares", id: "shares", placeholder: "50", type: "number" },
                    { label: "Avg Price ($)", id: "avgPrice", placeholder: "145.50", type: "number" },
                    { label: "Notes (optional)", id: "notes", placeholder: "Long-term hold" },
                  ].map(f => (
                    <div key={f.id} className="form-field">
                      <label>{f.label}</label>
                      <input
                        className="form-input"
                        type={f.type || "text"}
                        placeholder={f.placeholder}
                        value={newHolding[f.id]}
                        onChange={e => setNewHolding(p => ({ ...p, [f.id]: f.transform ? f.transform(e.target.value) : e.target.value }))}
                      />
                    </div>
                  ))}
                  <div className="form-field">
                    <label>Type</label>
                    <select className="form-select" value={newHolding.type} onChange={e => setNewHolding(p => ({ ...p, type: e.target.value }))}>
                      <option value="regular">Regular Stock</option>
                      <option value="penny">Penny Stock</option>
                    </select>
                  </div>
                  <div className="form-field">
                    <label>Currency</label>
                    <select className="form-select" value={newHolding.currency} onChange={e => setNewHolding(p => ({ ...p, currency: e.target.value }))}>
                      <option value="USD">🇺🇸 USD</option>
                      <option value="CAD">🇨🇦 CAD</option>
                    </select>
                  </div>
                </div>
                <div className="form-btns">
                  <button className="btn-cancel" onClick={() => setShowAddForm(false)}>Cancel</button>
                  <button className="btn-ok" onClick={addHolding}>Add Holding</button>
                </div>
              </div>
            )}

            <div className="holdings-list">
              {portfolio.holdings.length === 0
                ? <div className="empty">No holdings yet. Add your first stock above.</div>
                : portfolio.holdings.map((h, i) => (
                  <div key={i} className="holding-card">
                    <div className="h-ticker">{h.ticker}</div>
                    <div className={`h-badge ${h.type}`}>{h.type === "penny" ? "PENNY" : "STOCK"}</div>
                    <div className="h-detail">
                      {h.shares} shares @ <strong>${h.avgPrice}</strong>
                      {h.notes && <> · {h.notes}</>}
                    </div>
                    <div className="h-cur">{h.currency}</div>
                    <button className="h-del" onClick={() => removeHolding(h.ticker)}>✕</button>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
